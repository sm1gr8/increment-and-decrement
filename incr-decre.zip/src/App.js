import React from 'react'
import IncreDecre from './useState/IncreDecre'
import UseEffect from './useEffect/UseEffect'

const App = () => {
  return (
    <>
      <h3>Use of useState</h3>
      <IncreDecre />

      <h3>Use of UseEffect</h3>
      <UseEffect />
    </>
  )
}

export default App