import React, { useEffect, useState } from 'react'
import '../useState/style.css'

const UseEffect = () => {
    const [myNum, setMyNum] = useState(5);

    useEffect(() => {
        // document.title = `Chats(${myNum})`;
        document.title = (`Chats (` + myNum + ')');
    });
    // if we use arracy dependency it will load our data once when browser load like , []);

    return (
        <>
            <div className="center_div">
                <p>{myNum}</p>
                <div className="button2" onClick={() => setMyNum(myNum + 1)}>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    INCR
                </div>
                <div className="button2" onClick={() => setMyNum(0)}>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    UNSET
                </div>
            </div>
        </>
    )
}

export default UseEffect